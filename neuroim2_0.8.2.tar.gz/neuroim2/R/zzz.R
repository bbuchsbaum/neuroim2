#' @useDynLib neuroim2, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom stats sd
NULL
