if(getRversion() >= "2.15.1") {
  utils::globalVariables(c("%>%", "map_chr", "isplit"))
}

