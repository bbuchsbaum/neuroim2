library(testthat)
library(neuroim2)

test_check("neuroim2")
